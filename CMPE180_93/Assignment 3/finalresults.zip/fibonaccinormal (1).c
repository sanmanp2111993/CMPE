/*fibonacci wihout recursion */
/* Algorithm : 
1.take a user input num  
2. initialise the variable a=1 , b=1
3.calculate the fibonacci addition using the two variables a and b.  
3 using for loop calculate the fibonacci series for the variable .
5. output the fibonacci series .
*/ 
#include <iostream>
using namespace std;

int main() // main() function 
{
    int num, a = 1, b = 1, nextTerm;
    cout << "Enter number of terms: ";
    cin >> num; // input the term till fibonacci series should be formed 

    cout << "Fibonacci Series: " << a << " , " << b << " , " ;
    for (int i = 1; i <= num-2; ++i) // 
{
        nextTerm = a + b; // next tremis the addition of the previous two values to get next value. 
        cout << nextTerm << " , ";
        a = b;
        b = nextTerm;
    }
    return 0;
}
