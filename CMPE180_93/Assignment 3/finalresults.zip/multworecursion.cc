/* Algorithm 
1.Start
2.input two variables n1 and n2 
3.cout both the terms inserted 
4.compute the multiplication for both the variables 
5. output the product result.
*/

#include <iostream>
using namespace std;

int main( )
{
    float n1, n2, product;
    cout << "Enter two numbers: ";
    cin >> n1 >> n2;
    product = n1*n2;
    cout << "Product = " << product;
    return 0;
}
