//ALGORITHM: 
/*The following is the algorithm for the factorial:

    1.input a number n
    2.check if (n == 0)
    3.if num is equal to zero,prompt message - negative number not allowed. " 
    4.check if (n == 0), return 1.
    5.temp <= fact(num-1) * num [declare num].
    6.retrun temp.
    7.print result factorial(n). 
*/

#include <iostream>   //header file
 
using namespace std;
 
long factorial(long);
 
int main(void)
{
    long long n;        // long long datatype to store larger values
    cout<< "Enter a positive integer: ";
    cin>> n;
 
    if (n < 0)          // condition check for negetive values
        cout<< "negative number not allowed.\n";
    else
        cout << n << " factorial is: " << factorial(n) << endl; // call to a recursive factorial function
}
 
long factorial(long num)
{
    long temp;
 
    if(num <= 1) return 1;
 
    temp = num * factorial(num - 1);  // recursive procedure as function calling itself
    return temp;
}



