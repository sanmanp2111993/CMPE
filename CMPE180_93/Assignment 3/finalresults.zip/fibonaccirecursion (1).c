/* fibonacci using recursion*/
/*
algorithm : 
1.take a user input n 
2. initialise the variable i =0 
3 check for the snippet :if((n==1)||(n==0))
4. return the user input if the condition checks out to be true .
5.else use the recursive procedure call 
6. output the fibonacci series .
*/ 
 
#include<iostream> 
using namespace std;
 
int fib(int n) // fib ()function for fibonacci computation. 
{
    if((n==1)||(n==0))
    {
        return(n);
    }
    else
    {
        return(fib(n-1)+fib(n-2));// recursively function fib  calling itself  
    }
}
 
int main() // main () function 
{
    int n,i=0;
    cout<<"Input the number of terms for fibonacci Series:";
    cin>>n;
    cout<<"Fibonnaci Series is as follows\n";
 
    while(i<n)
    {
        cout<<" "<<fib(i);// calling fib() function for the integer value i.
        i++;
    }
 
    return 0;
}
