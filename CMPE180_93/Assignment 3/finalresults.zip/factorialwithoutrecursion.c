/* factorial without Recursion*/
// Algorithm:
/*the following is the algorithm for the factorial : 
1. input a number num 
2. set a variable fact as 1 
3. fact <= fact*num 
4. decrease num   
5. print result fact .*/  
#include <iostream>
using namespace std;

int main() 
{
    int i, num, fact = 1;

    cout<<"Enter a positive integer: ";
    cin>>num;

    for (i = 1; i <= num; ++i) {
        fact *= i;   // fact = fact * i;
    }

    cout<< "Factorial of "<<num<<" = "<<fact<< endl;
    return 0;
}
