/* Algorithm :
1.Start 
2.pass two variables in the function mul 
3.take two inputs from the user 
4. check for the condition if (x==0) (y==0)
5 return 0 if the above condition stands true 
6.else  return the recursive procedure call
7.stop
*/

#include <iostream>
using namespace std;
int mul(int x,int y);

//MAIN STARTS

int main()
{
int x,y;
cout<<"Enter first number : ";
cin>>x;

cout<<"\nEnter second number : ";
cin>>y;
cout<<"\nThe Multiplication result is : "<<mul(x,y)<<endl;
 return 0;
}

//MAIN ENDS

int mul(int x , int y)
{
if (y==0)
return 0;
if (x==0)
return 0;
else
return (x + mul(x,y-1));
}
